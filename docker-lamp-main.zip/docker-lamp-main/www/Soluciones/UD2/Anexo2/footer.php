<footer class="bg-dark text-white text-center py-2">
    <p>© 2024 Marco Magán Sanz - Todos los derechos reservados.</p>
</footer>